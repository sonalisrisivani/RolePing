import {HttpCrawler,Configuration} from 'crawlee';
import fs from 'node:fs';
const [url,out]=process.argv.slice(2);const t=performance.now();
const crawler=new HttpCrawler({maxConcurrency:1,maxRequestRetries:0,requestHandlerTimeoutSecs:30,useSessionPool:false,
 async requestHandler({response,body}){fs.writeFileSync(out,JSON.stringify({tool:'crawlee',url,seconds:(performance.now()-t)/1000,status:response.statusCode,data:JSON.parse(body.toString())},null,2));},
 async failedRequestHandler({request},error){fs.writeFileSync(out,JSON.stringify({tool:'crawlee',url,seconds:(performance.now()-t)/1000,error:String(error)},null,2));}
},new Configuration({persistStorage:false}));
await crawler.run([url]);
