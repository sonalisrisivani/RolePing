import {scrapeJobs} from 'ts-jobspy';
import fs from 'node:fs';
const [site,query,out]=process.argv.slice(2);
const t=performance.now();
let result;
try {
 const r=await scrapeJobs({sites:[site],searchTerm:query,location:'Bengaluru',country:'india',resultsWanted:10,hoursOld:168,linkedin:{fetchDescription:true},dedupe:'none',timeoutMs:60000,verbose:2});
 result={tool:'ts-jobspy',site,query,seconds:(performance.now()-t)/1000,...r};
}catch(e){result={tool:'ts-jobspy',site,query,seconds:(performance.now()-t)/1000,jobs:[],error:String(e)}}
fs.writeFileSync(out,JSON.stringify(result,null,2));
console.log(JSON.stringify({...result,jobs:result.jobs.length}));
