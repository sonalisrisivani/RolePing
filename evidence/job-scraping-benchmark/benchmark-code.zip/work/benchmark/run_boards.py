import subprocess,json,time,datetime
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
raw=ROOT/'work/benchmark/raw'
runs=[]
# Interleave tools; each site sees only one active request stream from this harness.
for qi,q in enumerate(['software engineer intern','graduate engineer trainee']):
 for site in ['indeed','naukri','linkedin']:
  order=['python','ts'] if qi==0 else ['ts','python']
  for tool in order:
   out=raw/f'{tool}-{site}-{qi}.json'
   cmd=([str(ROOT/'work/bench-venv/bin/python'),str(ROOT/'work/benchmark/jobspy_python.py')] if tool=='python' else ['node',str(ROOT/'work/nodebench/bench.mjs')])+[site,q,str(out)]
   start=datetime.datetime.now(datetime.timezone.utc).isoformat(); t=time.monotonic()
   try:
    p=subprocess.run(cmd,capture_output=True,text=True,timeout=90,cwd=ROOT)
    log=p.stdout+'\n'+p.stderr
    status='completed' if p.returncode==0 else 'process_error'
   except subprocess.TimeoutExpired as e:
    status='timeout';log=str(e.stdout or '')+'\n'+str(e.stderr or '')
   (raw/f'{tool}-{site}-{qi}.log').write_text(log)
   row={'tool':tool,'site':site,'query':q,'start':start,'wall_seconds':round(time.monotonic()-t,2),'status':status,'file':out.name}
   if out.exists():
    r=json.loads(out.read_text());row['count']=len(r.get('jobs',[]));row['meta']=r.get('meta');row['error']=r.get('error')
   runs.append(row);(raw/'board_runs.json').write_text(json.dumps(runs,indent=2))
   print(json.dumps(row),flush=True)
   time.sleep(3)
