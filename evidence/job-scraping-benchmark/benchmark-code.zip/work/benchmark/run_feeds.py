import subprocess,time,json,datetime
from pathlib import Path
root=Path(__file__).resolve().parents[2];raw=root/'work/benchmark/raw'
feeds=json.loads((root/'work/benchmark/feeds.json').read_text());runs=[]
for repeat in range(2):
 for feed in feeds:
  for tool in (['requests','scrapy','crawlee'] if repeat==0 else ['crawlee','scrapy','requests']):
   out=raw/f"feed-{tool}-{feed['source']}-{repeat}.json"
   cmd=([str(root/'work/bench-venv/bin/python'),str(root/'work/benchmark/feed_python.py'),tool] if tool!='crawlee' else ['node',str(root/'work/nodebench/feed.mjs')])+[feed['url'],str(out)]
   t=time.monotonic();start=datetime.datetime.now(datetime.timezone.utc).isoformat()
   try:
    p=subprocess.run(cmd,capture_output=True,text=True,timeout=45,cwd=root/'work/benchmark');log=p.stdout+'\n'+p.stderr;status='completed' if p.returncode==0 else 'process_error'
   except subprocess.TimeoutExpired as e:log=str(e);status='timeout'
   out.with_suffix('.log').write_text(log)
   row={**feed,'tool':tool,'repeat':repeat,'start':start,'wall_seconds':round(time.monotonic()-t,3),'status':status,'file':out.name}
   if out.exists():
    r=json.loads(out.read_text());data=r.get('data');row.update(seconds=r['seconds'],http_status=r.get('status'),error=r.get('error'),count=len(data if isinstance(data,list) else (data or {}).get('jobs',[])))
   runs.append(row);(raw/'feed_runs.json').write_text(json.dumps(runs,indent=2));print(json.dumps(row),flush=True)
   time.sleep(1)
