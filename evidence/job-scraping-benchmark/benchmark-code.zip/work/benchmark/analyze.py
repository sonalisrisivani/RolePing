import json,csv,statistics,re,shutil,zipfile,importlib.metadata
from pathlib import Path
root=Path(__file__).resolve().parents[2];raw=root/'work/benchmark/raw';out=root/'outputs/job-scraping-benchmark'
out.mkdir(exist_ok=True)
# Manual review of returned descriptions against a generic engineering fresher with
# no required professional experience. Degree/year/specialism still need matching.
audit={
 ('indeed',0):[(0,'Unclear: title says intern, description requests deep platform engineering experience'),(0,'Requires 3-5 years professional experience'),(1,'QA internship'),(0,'Requires 1-2 years professional coding experience'),(0,'Requires 1-2 years professional coding experience')],
 ('indeed',1):[(1,'Recent graduate/up to 1 year'),(1,'0-2 years; college project experience'),(1,'Fresher/up to 1 year'),(1,'Graduate trainee; no required professional tenure stated')],
 ('linkedin',0):[(1,'Explicit zero years and student/recent graduate'),(1,'Intern; coursework/projects accepted'),(1,'AI internship; practical skills required'),(1,'0-1 years'),(0,'Requires 6 months-1 year experience'),(1,'Description identifies software intern'),(1,'Description identifies software intern'),(1,'2027 circuital graduates only'),(1,'Pre-final/final year; degree/batch and availability checks needed'),(1,'2027 circuital graduates only')],
 ('linkedin',1):[(1,'0-1 years'),(1,'Explicit engineering freshers'),(1,'0-2 years'),(1,'Recent graduate/up to 1 year'),(1,'Explicit engineering freshers'),(1,'Recent graduate/up to 1 year'),(1,'Fresher/up to 1 year'),(0,'About 1 year professional network engineering experience'),(1,'Graduate trainee; no required professional tenure stated'),(1,'Fresh BTech; description publication date older than listing date')],
 ('naukri',0):[(0,'Title/description conflict: software intern vs senior digital marketing; direct URL mentions UI/UX'),(1,'Student/graduate internship'),(1,'Junior QA skills; college projects acceptable'),(1,'Intern; no professional tenure stated'),(1,'1-2 years may include capstone/coursework/internships'),(1,'Students/recent graduates accepted')],
 ('naukri',1):[(1,'Graduate trainee; 0-5 range'),(1,'Fresher; 0-2 range'),(1,'Graduate trainee; 0-5 range'),(0,'8-10 years'),(1,'Fresher; 2024/2025 batch only'),(0,'6-11 years'),(0,'6-11 years'),(1,'Freshers accepted'),(1,'Fresher; 0-1 range'),(0,'Training program; employment offer unclear')]
}
def speed(t):
 return 10 if t<=2 else 8 if t<=5 else 6 if t<=15 else 4 if t<=30 else 2 if t<=60 else 0
def writecsv(name,rows):
 if rows:
  with (out/name).open('w') as f:
   w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
runs=json.loads((raw/'board_runs.json').read_text());jobrows=[];summary=[];sources=[]
labels={}
for (site,qi),notes in audit.items():
 jobs=json.loads((raw/f'python-{site}-{qi}.json').read_text())['jobs']
 assert len(notes)==len(jobs)
 for j,(ok,note) in zip(jobs,notes): labels[j['job_url']]=(ok,note)
for tool in ['python','ts']:
 tr=[r for r in runs if r['tool']==tool]; allj=[]
 for r in tr:
  d=json.loads((raw/r['file']).read_text());js=[]
  for j in d['jobs']:
   url=j.get('job_url',j.get('jobUrl'));ok,note=labels[url]
   x={'tool':tool,'source':r['site'],'query':r['query'],'title':j['title'],'company':j['company'],'url':url,'location':j['location'],'date':j.get('date_posted',j.get('datePosted')),'description_chars':len(j.get('description') or ''),'salary_min':j.get('min_amount',j.get('minAmount')),'salary_max':j.get('max_amount',j.get('maxAmount')),'salary_period':j.get('interval'),'currency':j.get('currency'),'fresher_plausible':ok,'audit_note':note}
   js.append(x);jobrows.append(x)
  allj.extend(js)
 for site in ['indeed','naukri','linkedin']:
  sr=[r for r in tr if r['site']==site];sj=[j for j in allj if j['source']==site];n=len(sj)
  sources.append({'tool':tool,'source':site,'successful_nonempty_searches':sum(bool(r['count']) and not r['error'] for r in sr),'searches':len(sr),'returned_records':n,'median_wall_seconds':round(statistics.median(r['wall_seconds'] for r in sr),2),'descriptions':sum(j['description_chars']>100 for j in sj),'dated_records':sum(bool(j['date']) for j in sj),'fresher_plausible':sum(j['fresher_plausible'] for j in sj),'structured_salary_records':sum(j['salary_min'] is not None for j in sj)})
 n=len(allj);successful=[r for r in tr if r['count'] and not r['error']]
 comp=sum(sum([bool(j['title']),bool(j['company']),bool(j['url']),bool(j['location']),j['description_chars']>100,bool(j['date'])]) for j in allj)/(6*n)
 rel=sum(j['fresher_plausible'] for j in allj)/n;t=statistics.median(r['wall_seconds'] for r in successful)
 a=10*len(successful)/len(tr);b=10*comp;c=10*rel;d=speed(t)
 summary.append({'tool':tool,'records':n,'successful_searches':len(successful),'attempts':len(tr),'retrieval_score':round(a,2),'field_presence_score':round(b,2),'fresher_suitability_score':round(c,2),'speed_score':d,'median_success_wall_seconds':round(t,2),'overall':round(.3*a+.25*b+.35*c+.1*d,2)})
feeds=json.loads((raw/'feed_runs.json').read_text());frameworks=[]
for tool in ['requests','scrapy','crawlee']:
 rr=[r for r in feeds if r['tool']==tool];preserved=0
 for r in rr:
  got=json.loads((raw/r['file']).read_text()).get('data');ref=json.loads((raw/f"feed-requests-{r['source']}-0.json").read_text())['data']
  preserved+=got==ref
 t=statistics.median(r['wall_seconds'] for r in rr);a=sum(r.get('http_status')==200 for r in rr)/len(rr)*10;b=preserved/len(rr)*10;d=speed(t)
 frameworks.append({'tool':tool,'successful_fetches':sum(r.get('http_status')==200 for r in rr),'attempts':len(rr),'identical_payloads':preserved,'median_wall_seconds':round(t,3),'retrieval_score':a,'payload_preservation_score':b,'speed_score':d,'overall':round(.4*a+.4*b+.2*d,2)})
writecsv('scraper-ratings.csv',summary);writecsv('source-results.csv',sources);writecsv('job-audit.csv',jobrows);writecsv('framework-ratings.csv',frameworks)
(out/'measurements.json').write_text(json.dumps({'board_runs':runs,'feed_runs':feeds,'scraper_ratings':summary,'framework_ratings':frameworks,'link_checks':json.loads((raw/'link_checks.json').read_text())},indent=2))
versions={p:importlib.metadata.version(p) for p in ['python-jobspy','scrapy','requests']}
for p in ['ts-jobspy','crawlee']:versions[p]=json.loads((root/f'work/nodebench/node_modules/{p}/package.json').read_text())['version']
(out/'versions.json').write_text(json.dumps(versions,indent=2))
print(json.dumps({'summary':summary,'sources':sources,'frameworks':frameworks,'versions':versions},indent=2))
