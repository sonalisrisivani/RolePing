import sys, json, time
from pathlib import Path
from jobspy import scrape_jobs
site, query, out = sys.argv[1:]
t=time.monotonic()
try:
    df=scrape_jobs(site_name=[site], search_term=query, location='Bengaluru', country_indeed='India', results_wanted=10, hours_old=168, fetch_description=True, verbose=2)
    result={'tool':'python-jobspy','site':site,'query':query,'seconds':time.monotonic()-t,'jobs':json.loads(df.to_json(orient='records',date_format='iso'))}
except Exception as e:
    result={'tool':'python-jobspy','site':site,'query':query,'seconds':time.monotonic()-t,'jobs':[],'error':repr(e)}
Path(out).write_text(json.dumps(result,indent=2))
print(json.dumps({k:v for k,v in result.items() if k!='jobs'}), 'jobs=',len(result['jobs']))
