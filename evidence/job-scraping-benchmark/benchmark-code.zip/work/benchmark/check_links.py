import json,time,requests,re
from pathlib import Path
from bs4 import BeautifulSoup
root=Path(__file__).resolve().parents[2];raw=root/'work/benchmark/raw';targets=[]
for site in ['indeed','naukri','linkedin']:
 for qi,idx in [(0,0),(0,1),(1,0)]:
  j=json.loads((raw/f'python-{site}-{qi}.json').read_text())['jobs'][idx]
  targets.append({'source':site,'title':j['title'],'url':j['job_url']})
for source in ['greenhouse','lever','ashby']:
 d=json.loads((raw/f'feed-requests-{source}-0.json').read_text())['data'];jobs=d if isinstance(d,list) else d['jobs']
 for j in jobs[:2]: targets.append({'source':source,'title':j.get('title',j.get('text')),'url':j.get('absolute_url') or j.get('hostedUrl') or j.get('jobUrl')})
results=[]
for x in targets:
 t=time.monotonic()
 try:
  r=requests.get(x['url'],timeout=15);soup=BeautifulSoup(r.text,'html.parser');txt=soup.get_text(' ',strip=True)
  x.update(status=r.status_code,final_url=r.url,page_title=soup.title.get_text() if soup.title else None,title_present=x['title'].casefold() in txt.casefold(),closed_marker=bool(re.search(r'no longer accepting applications|job is no longer available|position has been filled',txt,re.I)))
 except Exception as e:x['error']=str(e)
 x['seconds']=round(time.monotonic()-t,2);results.append(x);(raw/'link_checks.json').write_text(json.dumps(results,indent=2));print(json.dumps(x),flush=True);time.sleep(.5)
