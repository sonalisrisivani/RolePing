import sys,json,time
from pathlib import Path
tool,url,out=sys.argv[1:]; t=time.monotonic()
if tool=='requests':
 import requests
 try:
  r=requests.get(url,timeout=25);r.raise_for_status()
  result={'tool':tool,'url':url,'seconds':time.monotonic()-t,'status':r.status_code,'data':r.json()}
 except Exception as e: result={'tool':tool,'url':url,'seconds':time.monotonic()-t,'error':str(e)}
 Path(out).write_text(json.dumps(result,indent=2))
else:
 import scrapy
 from scrapy.crawler import CrawlerProcess
 class Feed(scrapy.Spider):
  name='feed'
  async def start(self):
   yield scrapy.Request(url,callback=self.parse,errback=self.failed)
  def parse(self,response):
   Path(out).write_text(json.dumps({'tool':tool,'url':url,'seconds':time.monotonic()-t,'status':response.status,'data':response.json()},indent=2))
  def failed(self,failure):
   Path(out).write_text(json.dumps({'tool':tool,'url':url,'seconds':time.monotonic()-t,'error':str(failure.value)},indent=2))
 process=CrawlerProcess({'LOG_LEVEL':'ERROR','ROBOTSTXT_OBEY':False,'RETRY_ENABLED':False,'DOWNLOAD_TIMEOUT':25,'CONCURRENT_REQUESTS':1,'TELNETCONSOLE_ENABLED':False})
 process.crawl(Feed);process.start()
